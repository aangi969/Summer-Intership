import os
import sys
from pathlib import Path

# Get the base directory
BASE_DIR = Path(__file__).resolve().parent

# Add the CareerAdvisor directory to the Python path
sys.path.insert(0, str(BASE_DIR / 'CareerAdvisor'))

# Set Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'CareerAdvisor.settings')

# Import the Django WSGI application
from django.core.wsgi import get_wsgi_application

# Create the WSGI application
application = get_wsgi_application()

# Create a simple middleware to serve static files in development
from django.contrib.staticfiles.handlers import StaticFilesHandler
app = StaticFilesHandler(application)

